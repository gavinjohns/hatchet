// HATCHET — the first night: fully client-side game.
// This module exists to satisfy the host packaging contract; all game
// logic runs in the browser (see index.html + src/).
module.exports = {};
